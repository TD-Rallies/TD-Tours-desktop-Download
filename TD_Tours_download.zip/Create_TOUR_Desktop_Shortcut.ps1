# TOUR – Create Desktop Shortcut
# Place this script in the APP ROOT folder beside TD_simple.ico.
# The launcher must be in: System\Launch_TOUR.cmd

$ErrorActionPreference = "Stop"

try {
  $base     = Split-Path -Parent $MyInvocation.MyCommand.Path
  $launcher = Join-Path $base "System\Launch_TOUR.cmd"
  $icon     = Join-Path $base "TD_simple.ico"

  if (!(Test-Path -LiteralPath $launcher)) { throw "Missing file: $launcher" }
  if (!(Test-Path -LiteralPath $icon))     { throw "Missing file: $icon" }

  $desktop = [Environment]::GetFolderPath("Desktop")
  if ([string]::IsNullOrWhiteSpace($desktop) -or !(Test-Path -LiteralPath $desktop)) {
    throw "Desktop path not found: $desktop"
  }

  $shortcutPath = Join-Path $desktop "TOUR.lnk"
  $WshShell  = New-Object -ComObject WScript.Shell
  $shortcut  = $WshShell.CreateShortcut($shortcutPath)
  $shortcut.TargetPath        = $launcher
  $shortcut.WorkingDirectory  = Split-Path -Parent $launcher
  $shortcut.IconLocation      = $icon
  $shortcut.Save()

  Write-Host "Desktop shortcut created: TOUR"
  Write-Host "Target: $launcher"
  Write-Host "Icon:   $icon"
  Write-Host "Where:  $shortcutPath"
}
catch {
  Write-Host ""
  Write-Host "FAILED: $($_.Exception.Message)"
}
