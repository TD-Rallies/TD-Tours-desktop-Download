@echo off
REM TOUR - one-click setup (double-click this file)
REM Runs the PowerShell shortcut creator next to this file.
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0Create_TOUR_Desktop_Shortcut.ps1"
